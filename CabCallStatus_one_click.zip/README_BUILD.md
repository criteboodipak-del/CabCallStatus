# Cab & Call Status — Android APK Project

## Build APK with Android Studio (recommended)
1. Install the latest stable Android Studio.
2. Extract/open this `CabCallStatus` folder.
3. Android Studio should sync the Gradle project automatically.
4. If asked for a Gradle JDK, select **JDK 17**.
5. Wait for Gradle Sync to finish.
6. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. The debug APK will be created under:
   `app/build/outputs/apk/debug/app-debug.apk`
8. Copy that APK to your Android phone and install it.

## Requirements
- Android Studio with Android SDK Platform 35 installed
- JDK 17
- Internet connection for the first Gradle sync (to download Android Gradle Plugin/Kotlin dependencies)

## Current app
This version is a local demo. Statuses are stored only while the app process is running.
It does **not** monitor other people's calls or devices.

## Next version
For multiple phones, use a consent-based Firebase backend so each user can publish their own status and everyone in the group can see it in real time.
