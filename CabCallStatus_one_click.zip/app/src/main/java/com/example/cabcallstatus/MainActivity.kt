package com.example.cabcallstatus

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val people = mutableListOf("Rahul — Online", "Suman — Cab", "Amit — Call", "Raju — Offline")
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val name = findViewById<EditText>(R.id.nameInput)
        val status = findViewById<Spinner>(R.id.statusSpinner)
        val add = findViewById<Button>(R.id.addButton)
        val list = findViewById<ListView>(R.id.peopleList)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, people)
        list.adapter = adapter

        add.setOnClickListener {
            val n = name.text.toString().trim()
            if (n.isEmpty()) {
                Toast.makeText(this, "Name দিন", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val s = status.selectedItem.toString()
            people.add("$n — $s")
            adapter.notifyDataSetChanged()
            name.text.clear()
        }

        list.setOnItemClickListener { _, _, position, _ ->
            val statuses = arrayOf("Online", "Cab", "Call", "Offline")
            val current = people[position].substringAfter(" — ")
            val next = statuses[(statuses.indexOf(current).coerceAtLeast(0) + 1) % statuses.size]
            val person = people[position].substringBefore(" — ")
            people[position] = "$person — $next"
            adapter.notifyDataSetChanged()
        }
    }
}
